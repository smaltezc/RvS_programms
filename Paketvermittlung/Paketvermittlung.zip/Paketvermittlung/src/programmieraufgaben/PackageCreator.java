package programmieraufgaben;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;




public class PackageCreator {

    /**
     * Hier sollen die Kommandozeilen-Abfragen abgefragt und die Antworten
     * gespeichert werden
     * Es sollte auf Fehlerbehandlung geachtet werden (falsche Eingaben, ...)
     *
     * @param dataPackage Hier wird das Objekt übergeben in das die abgefragten Werte gespeichert werden sollen
     * @return Gibt das als Parameter übergebene Objekt, dass mit den abgefragten Werten befüllt wurde zurück
     */
    public DataPackage fillParameters(DataPackage dataPackage)  {

        //eklenti
        /*
        int dataPackageLength;
        Scanner input = new Scanner(System.in);
        String x = input.nextLine();
        dataPackageLength = Integer.parseInt(x);
        dataPackage = new DataPackage(dataPackageLength);
        */
        dataPackage = new DataPackage(dataPackage.getDataPackageLength());

        Scanner input1 = new Scanner(System.in);
        System.out.print("Version: ");
        String ver = input1.nextLine();
        ver = dataPackage.getVersion();

        Scanner input2 = new Scanner(System.in);
        System.out.print("Absender: ");
        String absn = input2.nextLine();
        absn = dataPackage.getAbsender();

        Scanner input3 = new Scanner(System.in);
        System.out.print("Empfänger: ");
        String empf = input3.nextLine();
        empf = dataPackage.getEmpfanger();

        /*
        Scanner input4 = new Scanner(System.in);
        System.out.print("Nachricht: ");
        String nachr = input4.next();
        nachr = dataPackage.getNachricht();
        */
        Scanner input4 = new Scanner(System.in);
        System.out.print("Nachricht: ");
        String nachr;
        input4.useDelimiter("\\t");
        while(true)
        {
            nachr = input4.next();
            break;
        }
        dataPackage.setNachricht(nachr) ;




        //eklenti

        return dataPackage;
    }

    /**
     * Aus dem als Parameter übergebenen Paket sollen die Informationen
     * ausgelesen und in einzelne Datenpakete aufgeteilt werden
     *
     * @param dataPackage Hier wird das Objekt übergeben in das das Resultat gespeichert werden soll
     * @return Gibt das als Parameter übergebene Objekt mit den aufgeteiltet Datenpaketen zurück
     */
    public List<DataPackage> splitPackage(DataPackage dataPackage) {
        List<DataPackage> dataPackages = new LinkedList<>();

        //eklenti
       // DataPackage x = fillParameters(dataPackage);

        String nachr = dataPackage.getNachricht();
        String parts[] = nachr.split(" ");
        System.out.println("asdas: "+parts.length);
        //eklenti
        
        String nachr1 =parts[i];
        dataPackage.setNachricht(nachr1);

        dataPackages.add(dataPackage);

        return dataPackages;
    }

    /**
     * Diese Methode gibt den Inhalt der empfangenen Pakete in der Komandozeile aus
     *
     * @param dataPackages Hier wird die Liste übergeben, deren Elemente in die Kommandozeile ausgegeben werden sollen
     */
    public void printOutPackage(List<DataPackage> dataPackages) {

    }
}
